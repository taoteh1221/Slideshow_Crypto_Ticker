#!/bin/bash

export DISPLAY=localhost:0.0   

DISPLAY=:0 

/usr/bin/xdotool key ctrl
