/opt/vc/bin/vcgencmd measure_temp
